package com.example.conversorgrados;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ConversorTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void convertirFarenheitToCelsius() {
        float input = 212;
        float output;
        float expected =100;
        float delta =.1f;
        Conversor conversor = new Conversor();
        output = conversor.convertirFarenheitToCelsius(input);
        assertEquals(expected,output,delta);
    }

    @Test
    public void convertirCelsiusToFarenheit() {
        float input = 32; // Celsius
        float output;
        float expected = 89.6f;
        float delta =.1f;
        Conversor conversor = new Conversor();
        output = conversor.convertirCelsiusToFarenheit(input);
        assertEquals(expected,output,delta);
    }
}