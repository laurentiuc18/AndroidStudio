package com.example.conversorgrados;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (EditText) findViewById(R.id.cantidad);
    }
    public void onClick(View view){
        switch (view.getId()){
            case R.id.btnConvertir:
                RadioButton celsiusButton = (RadioButton) findViewById(R.id.celsius);
                RadioButton farenheitButton = (RadioButton) findViewById(R.id.farenheit);
                TextView output = (TextView) findViewById(R.id.outputValue);

                if(text.getText().length() == 0){
                    Toast.makeText(this, "Introduce un número válido",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                float inputValue = Float.parseFloat(text.getText().toString());
                if (celsiusButton.isChecked()){
                    String result = String.valueOf(Conversor.convertirCelsiusToFarenheit(inputValue));
                    output.setText(result + " Farenheit");
                }else{
                    String result = String.valueOf(Conversor.convertirFarenheitToCelsius(inputValue));
                    output.setText(result + " Celsius");
                }


        }

    }
}