package com.example.conversorgrados;

public class Conversor {

    public static float convertirFarenheitToCelsius(float farenheit){
        return ((farenheit -32)*5/9);
    }

    public static float convertirCelsiusToFarenheit(float celsius){
        return ((celsius *9)/5)+32;
    }
}
