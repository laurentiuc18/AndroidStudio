package com.example.conversormonedas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (EditText) findViewById(R.id.cantidad);
    }
    public void onClick(View view){
        switch (view.getId()){
            case R.id.btnConvertir:
                RadioButton eurosButton = (RadioButton) findViewById(R.id.Euros);
                RadioButton dolaresButton = (RadioButton) findViewById(R.id.Dolares);
                RadioButton librasButton = (RadioButton) findViewById(R.id.Libras);

                RadioButton eurosButton2 = (RadioButton) findViewById(R.id.Euros2);
                RadioButton dolaresButton2 = (RadioButton) findViewById(R.id.Dolares2);
                RadioButton librasButton2 = (RadioButton) findViewById(R.id.Libras2);

                TextView output = (TextView) findViewById(R.id.outputValue);

                if(text.getText().length() == 0){
                    Toast.makeText(this, "Introduce un número válido",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                float inputValue = Float.parseFloat(text.getText().toString());
                if (eurosButton.isChecked()&&dolaresButton2.isChecked()){
                    String result = String.valueOf(Conversor.ConvertirEurosEnDolares(inputValue));
                    output.setText(result + " $");
                }
                if(dolaresButton.isChecked()&&eurosButton2.isChecked()) {
                    String result = String.valueOf(Conversor.ConvertirDolaresEnEuros(inputValue));
                    output.setText(result + "€");
                }
                if(dolaresButton.isChecked()&&librasButton2.isChecked()){
                    String result = String.valueOf(Conversor.ConvertirDolaresEnLibras(inputValue));
                    output.setText(result + "£");
                }
                if(eurosButton.isChecked()&&librasButton2.isChecked()){
                    String result = String.valueOf(Conversor.ConvertirEurosEnLibras(inputValue));
                    output.setText(result + "£");
                }
                if(librasButton.isChecked()&&dolaresButton2.isChecked()){
                    String result = String.valueOf(Conversor.ConvertirLibrasEnDolares(inputValue));
                    output.setText(result + "$");
                }
                if(librasButton.isChecked()&&eurosButton2.isChecked()){
                    String result = String.valueOf(Conversor.ConvertirLibrasEnEuros(inputValue));
                    output.setText(result + "€");
                }

                if(dolaresButton.isChecked()&&dolaresButton2.isChecked()){
                    Toast.makeText(getApplicationContext(),"No puedes convertir Dolares en Dolares",Toast.LENGTH_LONG).show();
                }
                if (eurosButton.isChecked()&&eurosButton2.isChecked()){
                    Toast.makeText(getApplicationContext(),"No puedes convertir Euros en Euros",Toast.LENGTH_LONG).show();
                }
                if(librasButton.isChecked()&&librasButton2.isChecked()){
                    Toast.makeText(getApplicationContext(),"No puedes convertir Libras en Libras",Toast.LENGTH_LONG).show();
                }

        }

    }
}