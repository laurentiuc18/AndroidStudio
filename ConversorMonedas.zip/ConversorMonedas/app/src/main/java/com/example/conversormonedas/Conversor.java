package com.example.conversormonedas;

public class Conversor {
    public static double ConvertirEurosEnDolares(double euros ){

        return euros= euros*1.21;
    }

    public static double ConvertirDolaresEnEuros(double dolares ){

        return dolares= dolares*0.83;
    }



    public static double ConvertirDolaresEnLibras(double dolares ){

        return dolares= dolares*0.75;
    }

    public static double ConvertirEurosEnLibras(double euros ){

        return euros= euros*0.91;
    }
    public static double ConvertirLibrasEnDolares(double libra ){

        return libra= libra*1.33;
    }
    public static double ConvertirLibrasEnEuros(double libra ){

        return libra= libra*1.11;
    }
}
