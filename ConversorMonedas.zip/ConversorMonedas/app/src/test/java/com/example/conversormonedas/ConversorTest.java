package com.example.conversormonedas;

import org.junit.Test;

import static org.junit.Assert.*;

public class ConversorTest {

    @Test
    public void convertirEurosEnDolares() {
        double input =100;
        double output;
        double expected=121;
        double delta =0.2;
        Conversor conversor = new Conversor();
        output = conversor.ConvertirEurosEnDolares(input);
        assertEquals(expected,output,delta);
    }

    @Test
    public void convertirDolaresEnEuros() {
        double input =100;
        double output;
        double expected=83;
        double delta =0.2;
        Conversor conversor = new Conversor();
        output = conversor.ConvertirDolaresEnEuros(input);
        assertEquals(expected,output,delta);
    }

    @Test
    public void convertirDolaresEnLibras() {
        double input =100;
        double output;
        double expected=75;
        double delta =0.2;
        Conversor conversor = new Conversor();
        output = conversor.ConvertirDolaresEnLibras(input);
        assertEquals(expected,output,delta);
    }

    @Test
    public void convertirEurosEnLibras() {
        double input =100;
        double output;
        double expected=91;
        double delta =0.2;
        Conversor conversor = new Conversor();
        output = conversor.ConvertirEurosEnLibras(input);
        assertEquals(expected,output,delta);
    }

    @Test
    public void convertirLibrasEnDolares() {
        double input =100;
        double output;
        double expected=133;
        double delta =0.2;
        Conversor conversor = new Conversor();
        output = conversor.ConvertirLibrasEnDolares(input);
        assertEquals(expected,output,delta);
    }

    @Test
    public void convertirLibrasEnEuros() {
        double input =100;
        double output;
        double expected=111;
        double delta =0.2;
        Conversor conversor = new Conversor();
        output = conversor.ConvertirLibrasEnEuros(input);
        assertEquals(expected,output,delta);
    }
}